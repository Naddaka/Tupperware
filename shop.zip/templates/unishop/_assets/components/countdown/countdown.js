$.mlsTime.countdown.init({
    scope: '[data-countdown]',
    item: '[data-countdown-item]',
    expireDateAttribute: 'data-countdown'
});