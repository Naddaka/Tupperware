$.mlsTime.countdown.init({
    scope: '[data-sales-timer]',
    item:  '[data-sales-timer-item]'
});