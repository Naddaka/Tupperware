(function () {
  svg4everybody();
})();