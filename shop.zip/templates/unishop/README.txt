Перед тем как работать с CSS и Javascript файлами шаблона, обязательно прочтите инструкцию
http://docs.imagecms.net/rabota-s-shablonom-multishop/rabota-s-css-i-javasctipt-dlia-razrabotchikov