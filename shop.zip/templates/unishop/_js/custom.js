/* 
* Use this file if you want to put custom scripts and do not want to use Gulp build
* Readmore - http://docs.imagecms.net/rabota-s-shablonom-multishop/rabota-s-css-i-javasctipt-dlia-razrabotchikov
*/